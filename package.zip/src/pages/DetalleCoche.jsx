import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../supabaseClient';
import { FaWhatsapp, FaRoad, FaGasPump, FaCalendarAlt, FaChevronLeft } from 'react-icons/fa';
import '../styles/DetalleCoche.css';

const DetalleCoche = () => {
    const { id } = useParams(); // Obtenemos el ID de la URL
    const navigate = useNavigate();
    const [coche, setCoche] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchCoche = async () => {
            try {
                const { data, error } = await supabase
                    .from('coches_venta')
                    .select('*')
                    .eq('id', id)
                    .single(); // Solo queremos un resultado

                if (error) throw error;
                setCoche(data);
            } catch (error) {
                console.error("Error:", error.message);
            } finally {
                setLoading(false);
            }
        };

        fetchCoche();
        window.scrollTo(0, 0);
    }, [id]);

    if (loading) return <div className="loading">Cargando detalles...</div>;
    if (!coche) return <div className="error">Vehículo no encontrado</div>;

    return (
        <div className="detalle-page-container">
            <button className="btn-back" onClick={() => navigate(-1)}>
                <FaChevronLeft /> Volver al catálogo
            </button>

            <div className="detalle-main-grid">
                {/* Columna Izquierda: Galería de imágenes (WebP recomendadas) */}
                <div className="detalle-galeria">
                    {coche.imagenes && coche.imagenes.map((img, idx) => (
                        <img key={idx} src={img} alt={`Vista ${idx + 1}`} className="img-detalle" />
                    ))}
                </div>

                {/* Columna Derecha: Información pegajosa (Sticky) */}
                <div className="detalle-sidebar">
                    <div className="sticky-content">
                        <span className="detalle-marca">{coche.marca}</span>
                        <h1>{coche.modelo}</h1>
                        <p className="detalle-precio">{Number(coche.precio).toLocaleString('es-ES')}€</p>

                        <div className="detalle-specs-grid">
                            <div className="item-spec">
                                <FaRoad />
                                <span>{Number(coche.kms).toLocaleString('es-ES')} km</span>
                            </div>
                            <div className="item-spec">
                                <FaGasPump />
                                <span>{coche.combustible}</span>
                            </div>
                            <div className="item-spec">
                                <FaCalendarAlt />
                                <span>{coche.año}</span>
                            </div>
                        </div>

                        <div className="detalle-descripcion">
                            <h3>Descripción</h3>
                            <p>{coche.descripcion}</p>
                        </div>

                        <button 
                            className="btn-contacto-whatsapp"
                            onClick={() => window.open(`https://wa.me/34600000000?text=Hola, me interesa el ${coche.marca} ${coche.modelo}`)}
                        >
                            <FaWhatsapp /> Contactar por WhatsApp
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DetalleCoche;