/* eslint-disable react-hooks/immutability */
import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import '../styles/ModalStock.css';

const ModalStock = ({ isOpen, onClose, onUpdate }) => {
  const [piezas, setPiezas] = useState([]);
  const [filtro, setFiltro] = useState(''); // Estado para el buscador
  const [nuevaPieza, setNuevaPieza] = useState({ nombre: '', referencia: '', stock: '', precio: '' });

  useEffect(() => {
    if (isOpen) cargarPiezas();
  }, [isOpen]);

  const cargarPiezas = async () => {
    const { data } = await supabase.from('piezas').select('*').order('nombre');
    setPiezas(data || []);
  };

  const agregarPieza = async () => {
    if (!nuevaPieza.nombre) return alert("Ponle un nombre a la pieza");
    
    const piezaParaInsertar = {
        nombre: nuevaPieza.nombre,
        referencia: nuevaPieza.referencia || '',
        stock: parseInt(nuevaPieza.stock) || 0,
        precio: parseFloat(nuevaPieza.precio) || 0,
        avisoStock: 5 
    };

    const { error } = await supabase.from('piezas').insert([piezaParaInsertar]);
    
    if (!error) {
      setNuevaPieza({ nombre: '', referencia: '', stock: '', precio: '' });
      cargarPiezas();
      if (onUpdate) onUpdate(); 
    } else {
      alert("Error al guardar la pieza: " + error.message);
    }
  };

  const actualizarStock = async (id, nuevoStock) => {
    const { error } = await supabase
      .from('piezas')
      .update({ stock: parseInt(nuevoStock) || 0 })
      .eq('id', id);

    if (!error) {
      cargarPiezas();
      if (onUpdate) onUpdate();
    } else {
      alert("Error al actualizar stock");
    }
  };

  const eliminarPieza = async (id) => {
    if (window.confirm("¿Eliminar esta pieza del inventario?")) {
      const { error } = await supabase.from('piezas').delete().eq('id', id);
      if (!error) {
        cargarPiezas();
        if (onUpdate) onUpdate();
      } else {
        alert("Error al eliminar la pieza");
      }
    }
  };

  // Filtrar piezas según el buscador
  const piezasFiltradas = piezas.filter(p => 
    p.nombre.toLowerCase().includes(filtro.toLowerCase()) || 
    p.referencia.toLowerCase().includes(filtro.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-contenido">
        <button className="cerrar-modal" onClick={onClose}>&times;</button>
        
        <h2 className="modal-titulo-inventario">
            📦 Gestión de Inventario
        </h2>

        <div className="formulario-pieza">
          <input 
            type="text" 
            placeholder="Pieza (ej: Batería)" 
            value={nuevaPieza.nombre} 
            onChange={e => setNuevaPieza({...nuevaPieza, nombre: e.target.value})} 
          />
          <input 
            type="text" 
            placeholder="Ref/SKU" 
            value={nuevaPieza.referencia} 
            onChange={e => setNuevaPieza({...nuevaPieza, referencia: e.target.value})} 
          />
          <input 
            type="number" 
            placeholder="Stock" 
            value={nuevaPieza.stock} 
            onChange={e => setNuevaPieza({...nuevaPieza, stock: e.target.value})} 
          />
          <input 
            type="number" 
            placeholder="Precio (€)" 
            value={nuevaPieza.precio} 
            onChange={e => setNuevaPieza({...nuevaPieza, precio: e.target.value})} 
          />
          <button className="btn-añadir-pieza" onClick={agregarPieza}>Añadir</button>
        </div>

        {/* BUSCADOR RÁPIDO */}
        <input 
          type="text" 
          className="buscador-inventario" 
          placeholder="🔍 Buscar pieza por nombre o referencia..." 
          value={filtro}
          onChange={(e) => setFiltro(e.target.value)}
        />

        <div className="tabla-scroll-contenedor">
            <table className="tabla-inventario">
              <thead>
                <tr>
                  <th>Nombre Pieza</th>
                  <th>Referencia</th>
                  <th>Stock</th>
                  <th>Precio</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {piezasFiltradas.length > 0 ? piezasFiltradas.map(pieza => (
                  <tr key={pieza.id}>
                    <td className="celda-nombre">{pieza.nombre}</td>
                    <td className="celda-referencia">{pieza.referencia || 'N/A'}</td>
                    <td>
                      <input 
                        type="number" 
                        defaultValue={pieza.stock} 
                        onBlur={(e) => actualizarStock(pieza.id, e.target.value)}
                      />
                    </td>
                    <td className="celda-precio">{pieza.precio}€</td>
                    <td>
                      <button className="btn-eliminar" onClick={() => eliminarPieza(pieza.id)}>Borrar</button>
                    </td>
                  </tr>
                )) : (
                    <tr>
                        <td colSpan="5" className="tabla-vacia-msg">
                            {filtro ? "No se encontraron piezas con esa búsqueda." : "No hay piezas registradas aún."}
                        </td>
                    </tr>
                )}
              </tbody>
            </table>
        </div>
      </div>
    </div>
  );
};

export default ModalStock;